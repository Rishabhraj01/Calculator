import styles from "./App.module.css";
import Display from "./container/Display";
import ButtonsContainer from "./container/ButtonsContainer";
import { useState } from "react"; //importing useState fn as we are managing state

function App() {
  const [calVal, setcalVal] = useState(""); //using state for storing data, calVal is currrent value and setcalVal is updater fn
  const onButtonClick = (buttonText) => {
    if (buttonText === "C") {
      setcalVal("");
    } else if (buttonText === "=") {
      const result = eval(calVal);
      setcalVal(result); // each setcalVal fn will re render the the page or again print the page
    } else {
      const newDisplayValue = calVal + buttonText;
      setcalVal(newDisplayValue);
    }
  };
  return (
    <div className={styles.calculator}>
      <Display displayValue={calVal}></Display>
      <ButtonsContainer onButtonClick={onButtonClick}></ButtonsContainer>
    </div> // display and ButtonsContainer are the two child components 1.in Display we are passing the calVal value as a prop and 2.in ButtonsContainer we are passing onButtonClick behaviour to the child and waiting for its respond
  );
}

export default App;
