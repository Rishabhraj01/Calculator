import styles from "./ButtonsContainer.module.css"; //importing css styles from css module (ButtonsContainer.module.css)
const ButtonsContainer = ({ onButtonClick }) => {
  //here onButtonClick is a parameter passed by parent App.jsx as a props
  const buttonNames = [
    "C",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "0",
    "+",
    "-",
    "/",
    "*",
    "=",
    ".",
  ];

  return (
    //used styles.buttonsContainer which comes from css module (ButtonsContainer.module.css)
    <div className={styles.buttonsContainer}>
      {buttonNames.map(
        (
          buttonName //mapping buttonName from buttonNames (from array to list)
        ) => (
          <button
            className={styles.button}
            onClick={() => onButtonClick(buttonName)} //handling event (onClick) through onButtonClick function which is declared in its parent App.jsx and passing the buttonName as value (connecting child to patrent) by emiting event
          >
            {buttonName}
          </button>
        )
      )}
    </div>
  );
};

export default ButtonsContainer;
