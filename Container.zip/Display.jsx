import styles from "./Display.module.css"; //importing css styles from css module (Display.module.css)
const Display = ({ displayValue }) => {
  //here displayValue is a parameter passed by parent App.jsx as a props
  return (
    <input
      className={styles.display} // used styles.display which comes from css module ( Display.module.css)
      type="text"
      value={displayValue} // here we use that props displayValue passed by parent App.jsx
      readOnly //this means the input is for read only
    />
  );
};

export default Display; //we have to export our component Display.jsx to its parent App.jsx
